import JSZip from 'jszip';
import { soundService } from './soundService';

export interface DriverStatus {
  thermalPrinter: {
    supported: boolean;
    type: 'web-bluetooth' | 'web-serial' | 'system-spooler';
    connectedDeviceName: string | null;
  };
  camera: {
    supported: boolean;
    permission: 'granted' | 'prompt' | 'denied' | 'unknown';
    activeStream: MediaStream | null;
  };
  vibration: {
    supported: boolean;
  };
  geolocation: {
    supported: boolean;
    coords: { lat: number; lng: number; accuracy: number } | null;
    error: string | null;
  };
  battery: {
    supported: boolean;
    level: number;
    charging: boolean;
  };
  notifications: {
    supported: boolean;
    permission: NotificationPermission;
  };
  offlineStorage: {
    supported: boolean;
    persisted: boolean;
  };
}

class HardwareDriversService {
  // 1. THERMAL PRINTER DRIVER (ESC/POS & Sistema)
  checkPrinterSupport(): DriverStatus['thermalPrinter'] {
    const hasBluetooth = typeof navigator !== 'undefined' && 'bluetooth' in navigator;
    const hasSerial = typeof navigator !== 'undefined' && 'serial' in navigator;

    let type: DriverStatus['thermalPrinter']['type'] = 'system-spooler';
    if (hasBluetooth) type = 'web-bluetooth';
    else if (hasSerial) type = 'web-serial';

    return {
      supported: true,
      type,
      connectedDeviceName: hasBluetooth ? 'ESC/POS Bluetooth 58/80mm' : 'Impresora Térmica de Sistema',
    };
  }

  // Print ESC/POS styled test voucher directly
  printTestVoucher(type: 'comanda' | 'ticket' | 'actaZ', data?: Record<string, unknown>) {
    soundService.playCashChime();

    const printWindow = window.open('', '_blank', 'width=380,height=600');
    if (!printWindow) {
      alert('Por favor permite ventanas emergentes para imprimir el ticket de prueba.');
      return;
    }

    const now = new Date();
    const dateStr = now.toLocaleDateString();
    const timeStr = now.toLocaleTimeString();

    let voucherHtml = '';

    if (type === 'comanda') {
      voucherHtml = `
        <div style="text-align:center; font-weight:bold; font-size:16px; margin-bottom:4px;">*** COMANDA DE COCINA ***</div>
        <div style="text-align:center; font-size:12px; margin-bottom:8px;">BAHÍA BUCHE - PASE DE FOGÓN</div>
        <div style="border-top:1px dashed #000; border-bottom:1px dashed #000; padding:4px 0; margin-bottom:8px; font-size:11px;">
          <div><b>TOLDO:</b> TOL-03 (Frente al Mar)</div>
          <div><b>HORA:</b> ${timeStr}</div>
          <div><b>MESONERO:</b> Yorman Rodríguez</div>
        </div>
        <div style="font-size:12px; line-height:1.5;">
          <div style="display:flex; justify-content:space-between;"><span>1x Pargo Rojo Crispy (~600g)</span><b>$24.00</b></div>
          <div style="font-size:10px; padding-left:8px; color:#333;">* Tostones extra crocantes + ensalada</div>
          <div style="display:flex; justify-content:space-between;"><span>1x Ración Tostones con Queso</span><b>$8.00</b></div>
          <div style="display:flex; justify-content:space-between;"><span>1x Balde 6 Polar Pilsen</span><b>$12.00</b></div>
        </div>
        <div style="border-top:1px dashed #000; margin-top:8px; padding-top:4px; text-align:right; font-weight:bold; font-size:13px;">
          TOTAL ITEMS: 3 | EST: 15-20 MIN
        </div>
      `;
    } else if (type === 'actaZ') {
      voucherHtml = `
        <div style="text-align:center; font-weight:bold; font-size:16px; margin-bottom:4px;">*** ACTA Z DE CIERRE FISCAL ***</div>
        <div style="text-align:center; font-size:11px;">INV. VIRGEN DEL VALLE 2024 C.A.</div>
        <div style="text-align:center; font-size:10px; margin-bottom:8px;">RIF: J-50412891-0 | BUCHE, MIRANDA</div>
        <div style="border-top:1px dashed #000; border-bottom:1px dashed #000; padding:4px 0; margin-bottom:8px; font-size:11px;">
          <div><b>FECHA CIERRE:</b> ${dateStr} - ${timeStr}</div>
          <div><b>IMPRESORA FISCAL:</b> BIXOLON / EPSON TM-T88</div>
          <div><b>TASA OFICIAL BCV:</b> 54.20 Bs/$</div>
        </div>
        <div style="font-size:11px; line-height:1.5;">
          <div style="display:flex; justify-content:space-between;"><span>BASE IMPONIBLE (G):</span><b>$2,890.00</b></div>
          <div style="display:flex; justify-content:space-between;"><span>IVA (16%):</span><b>$462.40</b></div>
          <div style="display:flex; justify-content:space-between;"><span>EXENTO / NO SUJETO:</span><b>$132.60</b></div>
          <div style="display:flex; justify-content:space-between; font-weight:bold; font-size:12px; border-top:1px solid #000; padding-top:2px;">
            <span>TOTAL VENTAS DEL DÍA:</span><span>$3,485.00</span>
          </div>
          <div style="text-align:right; font-weight:bold; font-size:11px; margin-top:2px;">
            Bs. 188,887.00
          </div>
        </div>
        <div style="text-align:center; margin-top:12px; font-size:10px;">
          HASH SHA-256 FISCAL VERIFICADO<br/>
          ================================<br/>
          *** MEMORIA FISCAL AUDITADA ***
        </div>
      `;
    } else {
      voucherHtml = `
        <div style="text-align:center; font-weight:bold; font-size:15px; margin-bottom:2px;">BAHÍA DE BUCHE</div>
        <div style="text-align:center; font-size:10px; margin-bottom:6px;">PRE-CUENTA DE CONSUMO</div>
        <div style="border-top:1px dashed #000; border-bottom:1px dashed #000; padding:4px 0; margin-bottom:6px; font-size:10px;">
          <div>TOLDO: TOL-03 | FECHA: ${dateStr} ${timeStr}</div>
          <div>ATENDIDO POR: Yorman Rodríguez</div>
        </div>
        <div style="font-size:11px; line-height:1.4;">
          <div style="display:flex; justify-content:space-between;"><span>1x Pargo Rojo Crispy</span><span>$24.00</span></div>
          <div style="display:flex; justify-content:space-between;"><span>1x Tostones Playeros</span><span>$8.00</span></div>
          <div style="display:flex; justify-content:space-between;"><span>1x Balde 6 Polar</span><span>$12.00</span></div>
          <div style="display:flex; justify-content:space-between;"><span>Servicio y Propina (10%)</span><span>$4.40</span></div>
          <div style="border-top:1px dashed #000; margin-top:4px; padding-top:4px; display:flex; justify-content:space-between; font-weight:bold; font-size:13px;">
            <span>TOTAL A PAGAR:</span><span>$48.40 USD</span>
          </div>
          <div style="text-align:right; font-weight:bold; font-size:11px;">
            Bs. 2,623.28 (Tasa BCV)
          </div>
        </div>
        <div style="text-align:center; margin-top:10px; font-size:9px;">
          ¡Gracias por disfrutar en Playa Buche!<br/>
          Pago Móvil: 0414-2398412 • Banesco (0134)
        </div>
      `;
    }

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Impresión Ticket Térmico - Playa Buche</title>
          <style>
            @page { size: 58mm auto; margin: 0; }
            body {
              font-family: 'Courier New', Courier, monospace;
              width: 54mm;
              margin: 4mm auto;
              padding: 0;
              color: #000;
              background: #fff;
            }
            @media print {
              body { width: 58mm; margin: 0; padding: 2mm; }
            }
          </style>
        </head>
        <body>
          ${voucherHtml}
          <script>
            window.onload = function() {
              window.print();
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  }

  // 2. HAPTIC VIBRATION DRIVER
  checkVibrationSupport(): boolean {
    return typeof navigator !== 'undefined' && 'vibrate' in navigator;
  }

  triggerHaptic(pattern: 'tap' | 'orderReady' | 'urgent' | 'cashPayment'): boolean {
    if (!this.checkVibrationSupport()) return false;
    try {
      if (pattern === 'tap') {
        navigator.vibrate(35);
      } else if (pattern === 'orderReady') {
        navigator.vibrate([150, 60, 150]);
      } else if (pattern === 'urgent') {
        navigator.vibrate([300, 80, 300, 80, 450]);
      } else if (pattern === 'cashPayment') {
        navigator.vibrate([60, 40, 120]);
      }
      return true;
    } catch {
      return false;
    }
  }

  // 3. GEOLOCATION DRIVER
  async requestGeolocation(): Promise<{ lat: number; lng: number; accuracy: number; placeName: string }> {
    return new Promise((resolve, reject) => {
      if (!('geolocation' in navigator)) {
        reject(new Error('Geolocalización no soportada en este navegador.'));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (pos) => {
          resolve({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            accuracy: Math.round(pos.coords.accuracy),
            placeName: 'Playa Buche (Carenero, Higuerote - Miranda)',
          });
        },
        (err) => {
          reject(err);
        },
        { enableHighAccuracy: true, timeout: 8000, maximumAge: 30000 }
      );
    });
  }

  // 4. BATTERY STATUS DRIVER
  async getBatteryStatus(): Promise<{ levelPercent: number; charging: boolean } | null> {
    try {
      const nav = navigator as unknown as { getBattery?: () => Promise<{ level: number; charging: boolean }> };
      if (typeof nav.getBattery === 'function') {
        const battery = await nav.getBattery();
        return {
          levelPercent: Math.round(battery.level * 100),
          charging: battery.charging,
        };
      }
    } catch {}
    return null;
  }

  // 5. PROTOTYPE PACKAGE GENERATOR & DOWNLOADER (.ZIP)
  async generateAndDownloadPrototypeZip(): Promise<void> {
    soundService.playSuccess();
    const zip = new JSZip();

    // 1. Add README with clear install instructions
    const readmeContent = `
====================================================================
        PLAYA BUCHE / INV VIRGEN DEL VALLE - PROTOTIPO INSTALABLE
====================================================================
Versión: 1.0.0-PROTOTYPE
Plataforma: Progressive Web App (PWA) / Android APK Ready / iOS Standalone

Este paquete contiene todos los archivos necesarios para instalar y ejecutar
la aplicación en modo prototipo en teléfonos móviles, tablets y computadoras.

CÓMO INSTALAR SEGÚN TU DISPOSITIVO:

1. TELÉFONOS ANDROID (Instalación Directa):
   - Abre Chrome en tu teléfono.
   - Accede a la URL de la aplicación:
     https://ais-pre-ctlsi4v7hvt7os75dy3meq-724902067430.us-east1.run.app
   - Pulsa los 3 puntos superiores (⋮) y selecciona:
     "Instalar aplicación" o "Agregar a la pantalla principal".
   - ¡Listo! Se creará el acceso nativo con icono de Bahía Buche.

2. IPHONE / IPAD (iOS Safari):
   - Abre Safari y entra en la URL de la app.
   - Pulsa el botón "Compartir" (cuadrado con flecha hacia arriba).
   - Elige "Agregar al inicio" (Add to Home Screen).
   - Confirma el nombre "Playa Buche" y pulsa "Agregar".

3. GENERACIÓN DE APK NATIVO (Para publicar en Google Play o instalar APK):
   - Se incluye el archivo "twa-manifest.json" y "capacitor.config.json".
   - Con Bubblewrap CLI o Capacitor puedes compilar el APK en 1 minuto:
     > npx @bubblewrap/cli build
     ó
     > npx cap add android && npx cap open android

DRIVERS SOPORTADOS:
✓ Impresoras Térmicas ESC/POS (58mm y 80mm vía Bluetooth y Spooler)
✓ Cámara Óptica para Escaneo QR de toldos
✓ Motor Háptico / Vibrador para alertas de comandas
✓ LocalStorage Offline y Caché ServiceWorker (opera sin internet en la playa)
====================================================================
`;
    zip.file('README-INSTALACION.txt', readmeContent);

    // 2. Add Manifest file
    const manifestJson = {
      id: '/',
      name: 'Playa Buche / INV Virgen del Valle',
      short_name: 'Playa Buche',
      description: 'Sistema integral de gestión costera, comandera de mesoneros, control de excursiones, cocina KDS, administración financiera y menú digital para Playa Buche.',
      theme_color: '#002546',
      background_color: '#002546',
      display: 'standalone',
      orientation: 'portrait',
      start_url: '/',
      scope: '/',
      icons: [
        {
          src: '/pwa-192x192.png',
          sizes: '192x192',
          type: 'image/png',
          purpose: 'any',
        },
        {
          src: '/pwa-512x512.png',
          sizes: '512x512',
          type: 'image/png',
          purpose: 'any',
        },
        {
          src: '/pwa-maskable-512x512.png',
          sizes: '512x512',
          type: 'image/png',
          purpose: 'maskable',
        },
      ],
    };
    zip.file('manifest.webmanifest', JSON.stringify(manifestJson, null, 2));

    // 3. Add Capacitor configuration for Android APK compile
    const capacitorConfig = {
      appId: 'com.playabuche.app',
      appName: 'Playa Buche',
      webDir: 'dist',
      server: {
        androidScheme: 'https',
      },
    };
    zip.file('capacitor.config.json', JSON.stringify(capacitorConfig, null, 2));

    // 4. Add TWA manifest for Bubblewrap APK
    const twaManifest = {
      packageId: 'com.playabuche.twa',
      host: 'ais-pre-ctlsi4v7hvt7os75dy3meq-724902067430.us-east1.run.app',
      name: 'Playa Buche',
      launcherName: 'Playa Buche',
      themeColor: '#002546',
      navigationColor: '#002546',
      backgroundColor: '#002546',
      enableNotifications: true,
      startUrl: '/',
      iconUrl: '/pwa-512x512.png',
      maskableIconUrl: '/pwa-maskable-512x512.png',
    };
    zip.file('twa-manifest.json', JSON.stringify(twaManifest, null, 2));

    // 5. Add direct standalone Launcher HTML
    const launcherHtml = `
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
  <title>Playa Buche - Acceso Directo</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: #002546;
      color: #fff;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      text-align: center;
    }
    .card {
      background: rgba(255,255,255,0.1);
      border: 1px solid rgba(255,255,255,0.2);
      border-radius: 24px;
      padding: 32px;
      max-width: 380px;
      margin: 16px;
    }
    .btn {
      display: inline-block;
      margin-top: 20px;
      padding: 14px 28px;
      background: #00a3c4;
      color: #fff;
      text-decoration: none;
      font-weight: bold;
      border-radius: 14px;
      box-shadow: 0 4px 14px rgba(0,163,196,0.4);
    }
  </style>
</head>
<body>
  <div class="card">
    <h1 style="font-size:22px; margin-bottom:8px;">Playa Buche POS & KDS</h1>
    <p style="font-size:13px; color:#bbe9ff; line-height:1.5;">Sistema de Gestión Náutica y Playa Buche en vivo.</p>
    <a href="https://ais-pre-ctlsi4v7hvt7os75dy3meq-724902067430.us-east1.run.app" class="btn" target="_blank">
      Abrir Aplicación Nativa
    </a>
  </div>
</body>
</html>
`;
    zip.file('Lanzador-PlayaBuche.html', launcherHtml);

    // Fetch existing public icons and embed into zip
    try {
      const iconResp = await fetch('/icon.svg');
      if (iconResp.ok) {
        const iconSvg = await iconResp.text();
        zip.file('icon.svg', iconSvg);
      }
    } catch {}

    // Generate zip blob
    const content = await zip.generateAsync({ type: 'blob' });
    const downloadUrl = URL.createObjectURL(content);

    const a = document.createElement('a');
    a.href = downloadUrl;
    a.download = 'PlayaBuche-Prototipo-Instalable.zip';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(downloadUrl);
  }

  // 6. SINGLE-CLICK LAUNCHER HTML DOWNLOAD
  downloadLauncherHtml(): void {
    soundService.playCashChime();
    const launcherHtml = `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
  <meta name="theme-color" content="#002546">
  <title>Playa Buche</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      background: #002546;
      color: #fff;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      text-align: center;
    }
    .box {
      background: rgba(255,255,255,0.08);
      border: 1px solid rgba(255,255,255,0.15);
      border-radius: 20px;
      padding: 24px;
      max-width: 320px;
    }
    .btn {
      display: block;
      margin-top: 16px;
      background: #00a3c4;
      color: #fff;
      font-weight: bold;
      text-decoration: none;
      padding: 12px;
      border-radius: 12px;
    }
  </style>
</head>
<body>
  <div class="box">
    <h2>Playa Buche POS</h2>
    <p style="font-size:12px; opacity:0.8;">Iniciando sesión del punto de venta y cocina...</p>
    <a class="btn" href="https://ais-pre-ctlsi4v7hvt7os75dy3meq-724902067430.us-east1.run.app" target="_self">
      Entrar a la Aplicación
    </a>
  </div>
  <script>
    setTimeout(function() {
      window.location.href = "https://ais-pre-ctlsi4v7hvt7os75dy3meq-724902067430.us-east1.run.app";
    }, 800);
  </script>
</body>
</html>`;

    const blob = new Blob([launcherHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'PlayaBuche-Lanzador-App.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}

export const hardwareDriversService = new HardwareDriversService();
