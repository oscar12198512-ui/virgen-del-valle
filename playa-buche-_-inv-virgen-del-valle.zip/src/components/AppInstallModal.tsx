import React, { useState, useEffect, useRef } from 'react';
import {
  Download,
  Smartphone,
  CheckCircle2,
  Camera,
  Bell,
  HardDrive,
  ExternalLink,
  X,
  Share2,
  PlusSquare,
  Sparkles,
  ShieldCheck,
  Printer,
  Vibrate,
  MapPin,
  BatteryCharging,
  Battery,
  FolderArchive,
  FileCode,
  Check,
  AlertCircle,
  Volume2
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { soundService } from '../services/soundService';
import { hardwareDriversService } from '../services/hardwareDriversService';

interface AppInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AppInstallModal: React.FC<AppInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'download' | 'drivers'>('download');
  
  // Camera driver state
  const [cameraStatus, setCameraStatus] = useState<'granted' | 'prompt' | 'denied' | 'unknown'>('unknown');
  const [isCameraActive, setIsCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Notification driver state
  const [notificationStatus, setNotificationStatus] = useState<'granted' | 'default' | 'denied'>('default');

  // GPS driver state
  const [gpsData, setGpsData] = useState<{ lat: number; lng: number; accuracy: number; placeName: string } | null>(null);
  const [gpsLoading, setGpsLoading] = useState(false);

  // Battery driver state
  const [batteryData, setBatteryData] = useState<{ levelPercent: number; charging: boolean } | null>(null);

  // Status notices
  const [actionNotice, setActionNotice] = useState<string | null>(null);
  const [isZipping, setIsZipping] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      stopCameraStream();
      return;
    }

    // Check notifications
    if ('Notification' in window) {
      setNotificationStatus(Notification.permission);
    }

    // Check camera permission
    if (navigator.permissions && navigator.permissions.query) {
      navigator.permissions
        .query({ name: 'camera' as PermissionName })
        .then((p) => setCameraStatus(p.state))
        .catch(() => setCameraStatus('unknown'));
    }

    // Query battery
    hardwareDriversService.getBatteryStatus().then((b) => {
      if (b) setBatteryData(b);
    });

    return () => {
      stopCameraStream();
    };
  }, [isOpen]);

  const stopCameraStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  const handleToggleCameraTest = async () => {
    soundService.playTap();
    if (isCameraActive) {
      stopCameraStream();
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 640 }, height: { ideal: 480 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setIsCameraActive(true);
      setCameraStatus('granted');
      soundService.playSuccess();
      setActionNotice('Driver de Cámara Activo: Transmisión óptica en vivo iniciada.');
      setTimeout(() => setActionNotice(null), 3500);
    } catch (err) {
      console.warn('Camera error:', err);
      setCameraStatus('denied');
      setActionNotice('⚠️ Error al iniciar sensor de cámara o permiso rechazado.');
      setTimeout(() => setActionNotice(null), 3500);
    }
  };

  const handleTestVibration = (pattern: 'tap' | 'orderReady' | 'urgent') => {
    soundService.playTap();
    const ok = hardwareDriversService.triggerHaptic(pattern);
    if (ok) {
      setActionNotice(`📳 Driver Háptico ejecutado: Patrón [${pattern}] emitido.`);
    } else {
      setActionNotice('Dispositivo sin motor de vibración háptico o en navegador no móvil.');
    }
    setTimeout(() => setActionNotice(null), 3000);
  };

  const handleTestPrint = (type: 'comanda' | 'actaZ' | 'ticket') => {
    soundService.playTap();
    hardwareDriversService.printTestVoucher(type);
    setActionNotice(`🖨️ Driver Térmico: Generado voucher ${type.toUpperCase()} para impresión ESC/POS.`);
    setTimeout(() => setActionNotice(null), 3500);
  };

  const handleRequestGps = async () => {
    soundService.playTap();
    setGpsLoading(true);
    try {
      const coords = await hardwareDriversService.requestGeolocation();
      setGpsData(coords);
      soundService.playSuccess();
      setActionNotice(`📍 Driver GPS Sincronizado: Precisión ±${coords.accuracy}m en Bahía Buche.`);
    } catch (err) {
      setActionNotice('⚠️ No se pudo obtener ubicación GPS (verifique permisos de localización).');
    } finally {
      setGpsLoading(false);
      setTimeout(() => setActionNotice(null), 4000);
    }
  };

  const handleRequestNotification = async () => {
    soundService.playTap();
    if (!('Notification' in window)) {
      setActionNotice('Este navegador no soporta Notificaciones Push Web.');
      return;
    }
    const perm = await Notification.requestPermission();
    setNotificationStatus(perm);
    if (perm === 'granted') {
      soundService.playCashChime();
      setActionNotice('✅ Driver de Notificaciones Activado: Alertas de cocina y pedidos habilitadas.');
      new Notification('Playa Buche', {
        body: 'Driver de avisos operativos listo. Notificaciones autorizadas.',
        icon: '/pwa-192x192.png',
      });
    } else {
      setActionNotice('⚠️ Permiso de notificaciones no concedido.');
    }
    setTimeout(() => setActionNotice(null), 3500);
  };

  const handleDownloadZip = async () => {
    soundService.playTap();
    setIsZipping(true);
    try {
      await hardwareDriversService.generateAndDownloadPrototypeZip();
      setActionNotice('📦 Paquete Prototipo descargado exitosamente (.ZIP con PWA, APK configs y Launcher).');
    } catch (err) {
      console.error(err);
      setActionNotice('Error al empaquetar prototipo.');
    } finally {
      setIsZipping(false);
      setTimeout(() => setActionNotice(null), 5000);
    }
  };

  const handleDownloadLauncher = () => {
    soundService.playTap();
    hardwareDriversService.downloadLauncherHtml();
    setActionNotice('📱 Archivo Lanzador Directo descargado (.html listo para guardar y abrir).');
    setTimeout(() => setActionNotice(null), 4000);
  };

  const handleOpenDirectWindow = () => {
    soundService.playTap();
    window.open(window.location.href, '_blank');
  };

  const handleNativeInstall = async () => {
    soundService.playTap();
    const ok = await install();
    if (ok) {
      soundService.playCashChime();
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/70 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden border border-gray-100 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-[#002546] text-white p-4 relative flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-[#eff4ff]/15 border border-white/20 flex items-center justify-center p-1.5 shrink-0">
              <img src="/icon.svg" alt="Playa Buche" className="w-full h-full object-contain" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-[#57d1fd] uppercase tracking-wider block">
                CONSOLA DE DESCARGA & DRIVERS
              </span>
              <h3 className="text-base font-extrabold leading-tight">
                Playa Buche • Prototipo Instalable
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-gray-200 bg-gray-50 px-4 pt-2 gap-2">
          <button
            onClick={() => {
              soundService.playTap();
              setActiveTab('download');
            }}
            className={`pb-2.5 px-3 text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 ${
              activeTab === 'download'
                ? 'border-[#002546] text-[#002546]'
                : 'border-transparent text-gray-500 hover:text-gray-800'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>Descargar Prototipo</span>
          </button>
          <button
            onClick={() => {
              soundService.playTap();
              setActiveTab('drivers');
            }}
            className={`pb-2.5 px-3 text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 ${
              activeTab === 'drivers'
                ? 'border-[#002546] text-[#002546]'
                : 'border-transparent text-gray-500 hover:text-gray-800'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Drivers & Hardware de Playa</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="p-4 overflow-y-auto space-y-4 text-xs text-gray-700">
          {/* Action notice toast */}
          {actionNotice && (
            <div className="p-3 bg-[#eff4ff] border border-[#a4c9fc] text-[#002546] rounded-xl font-bold text-xs flex items-center gap-2 animate-fade-in">
              <Sparkles className="w-4 h-4 text-[#006782] shrink-0" />
              <span>{actionNotice}</span>
            </div>
          )}

          {/* TAB 1: DESCARGA DEL PROTOTIPO */}
          {activeTab === 'download' && (
            <div className="space-y-3.5">
              {/* Primary Instant Download Card */}
              <div className="bg-[#eff4ff] border border-[#d2e4ff] rounded-2xl p-3.5 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="font-extrabold text-[#002546] text-xs flex items-center gap-1.5">
                    <FolderArchive className="w-4 h-4 text-[#006782]" /> Paquete Prototipo Completo
                  </span>
                  <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                    ZIP LISTO
                  </span>
                </div>
                <p className="text-[11px] text-gray-600 leading-relaxed">
                  Descarga directa del paquete de la aplicación con manifiesto PWA, configuración para compilar en 
                  <strong> Android APK (Capacitor / TWA)</strong>, iconos de alta resolución y lanzador offline.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={handleDownloadZip}
                    disabled={isZipping}
                    className="py-2.5 px-3 bg-[#006782] hover:bg-[#005870] disabled:bg-gray-400 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-colors"
                  >
                    <Download className="w-4 h-4" />
                    <span>{isZipping ? 'Empaquetando...' : 'Descargar Paquete ZIP'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleDownloadLauncher}
                    className="py-2.5 px-3 bg-[#002546] hover:bg-[#0d3b66] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-colors"
                  >
                    <FileCode className="w-4 h-4 text-[#57d1fd]" />
                    <span>Descargar Lanzador .HTML</span>
                  </button>
                </div>
              </div>

              {/* Direct Full-Screen Install Method (Solución Iframe) */}
              <div className="bg-white border border-gray-200 rounded-2xl p-3.5 space-y-2.5 shadow-2xs">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-[#002546] flex items-center gap-1.5">
                    <ExternalLink className="w-4 h-4 text-sky-600" /> Instalación Nativa en Dispositivo
                  </span>
                  {isInstalled && (
                    <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                      <Check className="w-3 h-3 text-emerald-600" /> Instalada
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-gray-600">
                  Para que tu navegador (Chrome, Edge o Safari) active el aviso de instalación nativo en tu pantalla de inicio, 
                  abre la app en una ventana directa fuera del visor de desarrollo:
                </p>
                <div className="flex flex-col sm:flex-row gap-2">
                  <button
                    type="button"
                    onClick={handleOpenDirectWindow}
                    className="flex-1 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-colors"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>Abrir en Pestaña Directa</span>
                  </button>

                  {isInstallable && (
                    <button
                      type="button"
                      onClick={handleNativeInstall}
                      className="py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <Download className="w-4 h-4" />
                      <span>Instalar en 1 Clic</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Instructions Guide */}
              <div className="bg-gray-50 border border-gray-200 rounded-2xl p-3 space-y-2 text-[11px]">
                <span className="font-bold text-[#002546] block">Guía Rápida de Instalación en Toldos / Playa:</span>
                <div className="space-y-1.5 text-gray-600">
                  <div>
                    <strong className="text-gray-800">📱 Android (Chrome):</strong> Al abrir la app en ventana directa, pulsa los 3 puntos (⋮) ➔ <em>"Instalar aplicación"</em>.
                  </div>
                  <div>
                    <strong className="text-gray-800">🍏 iPhone (Safari):</strong> Pulsa el botón <em>Compartir</em> <Share2 className="w-3 h-3 inline text-sky-600 mx-0.5" /> ➔ <em>"Agregar al inicio"</em> <PlusSquare className="w-3 h-3 inline text-gray-700 mx-0.5" />.
                  </div>
                  <div>
                    <strong className="text-gray-800">💻 PC / Mac (Chrome / Edge):</strong> Haz clic en el icono de instalación en la barra de direcciones del navegador.
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: DRIVERS & HARDWARE */}
          {activeTab === 'drivers' && (
            <div className="space-y-3">
              {/* 1. Driver de Impresora Térmica */}
              <div className="bg-white border border-gray-200 rounded-2xl p-3 shadow-2xs space-y-2">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-sky-50 text-[#006782] flex items-center justify-center">
                      <Printer className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-bold text-[#002546] text-xs">Driver Impresora Térmica ESC/POS</h4>
                      <span className="text-[10px] text-gray-500">Bluetooth / USB / Red (58mm y 80mm)</span>
                    </div>
                  </div>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Driver Conectado
                  </span>
                </div>
                <div className="flex items-center gap-1.5 pt-1">
                  <button
                    type="button"
                    onClick={() => handleTestPrint('comanda')}
                    className="flex-1 py-1.5 bg-[#eff4ff] hover:bg-[#dce9ff] text-[#002546] border border-[#d2e4ff] rounded-lg text-[10px] font-bold transition-colors"
                  >
                    Test Comanda Cocina
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTestPrint('actaZ')}
                    className="flex-1 py-1.5 bg-[#eff4ff] hover:bg-[#dce9ff] text-[#002546] border border-[#d2e4ff] rounded-lg text-[10px] font-bold transition-colors"
                  >
                    Test Acta Z Fiscal
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTestPrint('ticket')}
                    className="flex-1 py-1.5 bg-[#eff4ff] hover:bg-[#dce9ff] text-[#002546] border border-[#d2e4ff] rounded-lg text-[10px] font-bold transition-colors"
                  >
                    Test Pre-Cuenta
                  </button>
                </div>
              </div>

              {/* 2. Driver Óptico & Cámara QR */}
              <div className="bg-white border border-gray-200 rounded-2xl p-3 shadow-2xs space-y-2">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center">
                      <Camera className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-bold text-[#002546] text-xs">Driver Sensor Óptico & Cámara QR</h4>
                      <span className="text-[10px] text-gray-500">Escaneo de toldos y comprobantes bancarios</span>
                    </div>
                  </div>
                  <div>
                    {cameraStatus === 'granted' ? (
                      <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Permiso Activo
                      </span>
                    ) : (
                      <span className="text-[10px] bg-amber-100 text-amber-900 font-bold px-2 py-0.5 rounded-full">
                        Requiere Prueba
                      </span>
                    )}
                  </div>
                </div>

                <div className="pt-1">
                  <button
                    type="button"
                    onClick={handleToggleCameraTest}
                    className={`w-full py-2 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-2 ${
                      isCameraActive
                        ? 'bg-rose-600 hover:bg-rose-700 text-white'
                        : 'bg-[#002546] hover:bg-[#0d3b66] text-white'
                    }`}
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <span>{isCameraActive ? 'Apagar Prueba de Cámara' : 'Probar Cámara en Vivo (Sensor QR)'}</span>
                  </button>

                  {/* Video preview feed */}
                  {isCameraActive && (
                    <div className="mt-2 rounded-xl overflow-hidden border border-gray-300 bg-black aspect-video relative">
                      <video
                        ref={videoRef}
                        autoPlay
                        playsInline
                        muted
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                        <div className="w-40 h-40 border-2 border-emerald-400 border-dashed rounded-2xl animate-pulse"></div>
                      </div>
                      <span className="absolute bottom-2 left-2 bg-black/70 text-emerald-400 text-[10px] px-2 py-0.5 rounded font-mono">
                        SCANNER QR ACTIVO • 30 FPS
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* 3. Driver Motor Háptico / Vibrador */}
              <div className="bg-white border border-gray-200 rounded-2xl p-3 shadow-2xs space-y-2">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
                      <Vibrate className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-bold text-[#002546] text-xs">Driver Motor Háptico & Vibración</h4>
                      <span className="text-[10px] text-gray-500">Alertas táctiles para mesoneros en la arena</span>
                    </div>
                  </div>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                    Soportado
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-1.5 pt-1">
                  <button
                    type="button"
                    onClick={() => handleTestVibration('tap')}
                    className="py-1.5 px-2 bg-gray-100 hover:bg-gray-200 text-[#002546] rounded-lg text-[10px] font-bold transition-colors"
                  >
                    Vibración Toque
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTestVibration('orderReady')}
                    className="py-1.5 px-2 bg-gray-100 hover:bg-gray-200 text-[#002546] rounded-lg text-[10px] font-bold transition-colors"
                  >
                    Plato Listo
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTestVibration('urgent')}
                    className="py-1.5 px-2 bg-rose-50 hover:bg-rose-100 text-rose-800 rounded-lg text-[10px] font-bold transition-colors"
                  >
                    Alerta Crítica
                  </button>
                </div>
              </div>

              {/* 4. Driver Geolocalización Marina (Toldo & Muelle) */}
              <div className="bg-white border border-gray-200 rounded-2xl p-3 shadow-2xs space-y-2">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center">
                      <MapPin className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-bold text-[#002546] text-xs">Driver GPS & Telemetría de Playa</h4>
                      <span className="text-[10px] text-gray-500">Ubicación de toldos y aproximación de lanchas</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleRequestGps}
                    disabled={gpsLoading}
                    className="px-2.5 py-1 bg-[#002546] hover:bg-[#0d3b66] text-white rounded-lg text-[10px] font-bold transition-colors"
                  >
                    {gpsLoading ? 'Localizando...' : 'Probar GPS'}
                  </button>
                </div>
                {gpsData && (
                  <div className="bg-teal-50/70 border border-teal-200 p-2 rounded-xl text-[11px] text-teal-950 font-mono space-y-0.5">
                    <div><strong>Coordenadas:</strong> {gpsData.lat.toFixed(5)}, {gpsData.lng.toFixed(5)}</div>
                    <div><strong>Precisión:</strong> ±{gpsData.accuracy} metros ({gpsData.placeName})</div>
                  </div>
                )}
              </div>

              {/* 5. Driver Batería de Terminales & Memoria Offline */}
              <div className="grid grid-cols-2 gap-2">
                <div className="bg-white border border-gray-200 rounded-2xl p-3 shadow-2xs space-y-1">
                  <div className="flex items-center gap-1.5 text-[#006782]">
                    {batteryData?.charging ? (
                      <BatteryCharging className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <Battery className="w-4 h-4" />
                    )}
                    <span className="font-bold text-xs text-[#002546]">Driver Batería</span>
                  </div>
                  <div className="text-lg font-extrabold text-[#002546]">
                    {batteryData ? `${batteryData.levelPercent}%` : 'Sensor OK'}
                  </div>
                  <span className="text-[10px] text-gray-500 block">
                    {batteryData?.charging ? 'Cargando en Base POS' : 'Autonomía en Toldo'}
                  </span>
                </div>

                <div className="bg-white border border-gray-200 rounded-2xl p-3 shadow-2xs space-y-1">
                  <div className="flex items-center gap-1.5 text-emerald-700">
                    <HardDrive className="w-4 h-4" />
                    <span className="font-bold text-xs text-[#002546]">Memoria Offline</span>
                  </div>
                  <div className="text-lg font-extrabold text-[#002546]">Persistente</div>
                  <span className="text-[10px] text-gray-500 block">LocalStorage + ServiceWorker</span>
                </div>
              </div>

              {/* 6. Driver Notificaciones */}
              <div className="bg-white border border-gray-200 rounded-2xl p-3 shadow-2xs flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
                    <Bell className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-[#002546] text-xs">Driver Notificaciones Push</h4>
                    <span className="text-[10px] text-gray-500">Alertas sonoras y avisos de cocina</span>
                  </div>
                </div>
                {notificationStatus === 'granted' ? (
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Activo
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={handleRequestNotification}
                    className="px-2.5 py-1 bg-[#002546] hover:bg-[#0d3b66] text-white rounded-lg text-[10px] font-bold transition-colors"
                  >
                    Activar
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
          <div className="flex items-center gap-1 text-[11px] text-gray-500">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Playa Buche • Hardware & Prototipo Ready</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-xl text-xs font-bold transition-colors"
          >
            Cerrar Consola
          </button>
        </div>
      </div>
    </div>
  );
};
