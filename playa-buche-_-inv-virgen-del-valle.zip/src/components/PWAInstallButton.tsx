import React, { useState } from 'react';
import { Download, Smartphone } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { AppInstallModal } from './AppInstallModal';

interface PWAInstallButtonProps {
  className?: string;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ className = '' }) => {
  const { isInstallable, isInstalled, isIOS } = usePWAInstall();
  const [showModal, setShowModal] = useState(false);

  // If already running in standalone mode on mobile/desktop, we don't need to force install prompt,
  // but we can still allow viewing permissions if needed.
  return (
    <>
      <button
        type="button"
        onClick={() => setShowModal(true)}
        title="Descargar o configurar aplicación en este dispositivo"
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all active:scale-95 shadow-2xs ${
          isInstalled
            ? 'bg-[#eff4ff] text-[#002546] hover:bg-[#dce9ff] border border-[#a4c9fc]'
            : 'bg-emerald-600 hover:bg-emerald-700 text-white border border-emerald-500 shadow-md animate-pulse'
        } ${className}`}
      >
        {isInstalled ? (
          <>
            <Smartphone className="w-3.5 h-3.5 text-[#006782]" />
            <span>Drivers & App</span>
          </>
        ) : (
          <>
            <Download className="w-3.5 h-3.5 text-white" />
            <span className="hidden sm:inline">Descargar Prototipo</span>
            <span className="sm:hidden">Prototipo</span>
          </>
        )}
      </button>

      <AppInstallModal isOpen={showModal} onClose={() => setShowModal(false)} />
    </>
  );
};
